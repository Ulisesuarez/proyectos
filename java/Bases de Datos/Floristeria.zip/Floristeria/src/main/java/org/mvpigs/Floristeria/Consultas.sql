SELECT * FROM Objetivos;
